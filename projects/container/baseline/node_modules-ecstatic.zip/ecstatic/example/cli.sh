#!/bin/bash

../lib/ecstatic.js ./public --port 8080

