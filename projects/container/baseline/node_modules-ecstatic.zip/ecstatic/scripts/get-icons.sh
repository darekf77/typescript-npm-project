#!/bin/bash

rm -rf teambox-icons
git clone --depth=1 git@github.com:teambox/Free-file-icons.git teambox-icons
